create table if not exists recommand(
walk varchar(20),
bath varchar(20),
how varchar(300),
veg varchar(50),
fru varchar(50)

)default charset=utf8;