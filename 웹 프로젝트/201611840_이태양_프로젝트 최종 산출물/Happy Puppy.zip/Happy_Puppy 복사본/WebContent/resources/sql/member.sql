create table if not exists member(
id varchar(20),
pw varchar(20),
phone varchar(20),
primary key (id)

)default charset=utf8;